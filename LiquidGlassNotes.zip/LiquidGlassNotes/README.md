# Liquid Notes ✨ — Liquid Glass Notepad for Android

A **minimal, iOS-style, edge-to-edge notepad** built with **Jetpack Compose**, finished with
**Liquid Glass**: frosted translucent surfaces, bright glass edges, soft shadows and a live
blurred aurora wallpaper behind everything. Offline-first, no account, no tracking.

> 🇮🇷 راهنمای فارسی در انتهای این فایل است.

![Platform](https://img.shields.io/badge/platform-Android%2012%2B-green)
![Kotlin](https://img.shields.io/badge/Kotlin-2.0.20-purple)
![Compose](https://img.shields.io/badge/Jetpack%20Compose-Material3-blue)

## Features

- **Liquid Glass UI** — blurred aurora background, glass cards / top bars / search / FAB, iOS pastel palette, SF-style typography
- **Edge-to-edge** — draws behind status & navigation bars (`enableEdgeToEdge`)
- **Notes, done properly**
  - Create / edit with **autosave**, word count
  - **Pin 📌, Favourite ❤️, Colour 🎨** (8 iOS pastels)
  - **Folders / categories** — Personal, Work, Ideas, Study, Shopping, Travel, Other
  - **Checklist mode** — turn any note into a checklist with progress bar
  - **Reminders** — in-app reminder marker (1 hour / tomorrow / 1 week)
  - **Archive, Trash with Undo, Restore, Delete forever, Empty trash**
  - **Duplicate, Share** (system share sheet), **Export all notes**
- **Find fast** — full-text search, folder chips, Pinned / Favourites filters
- **Sort** by edited / created / title · **Grid (staggered, iOS Notes-style) or List**
- **Dark / Light / System theme**, saved preferences
- **Stats** in Settings (notes, pinned, favourites, total words…)
- **100% offline** — Room database on-device

## Tech stack

Kotlin 2.0.20 · Jetpack Compose (Material 3, BOM 2024.09) · Room 2.6.1 (KSP) ·
DataStore Preferences · Navigation Compose · Gradle 8.9 / AGP 8.5.2 · minSdk 31 (Android 12, for real blur), targetSdk 34, JDK 17

## Build locally

```bash
./gradlew assembleDebug      # debug APK -> app/build/outputs/apk/debug/
./gradlew assembleRelease    # release APK (minified)
# open in Android Studio: File > Open > this folder, then Run ▶
```

## Deploy with GitHub Actions 🚀

### Option A — one script (easiest)
```bash
chmod +x deploy-to-github.sh
./deploy-to-github.sh my-notes-app public
```
Creates the GitHub repo (needs [GitHub CLI](https://cli.github.com) + `gh auth login`), pushes the code and triggers the release build.

### Option B — manual
```bash
git init -b main && git add . && git commit -m "Liquid Notes"
gh repo create my-notes-app --public --source=. --push
# or: create the repo on github.com, then
# git remote add origin https://github.com/<you>/my-notes-app.git && git push -u origin main
```

### What the workflows do
| Workflow | Trigger | Result |
|---|---|---|
| `Android CI — Build APK` | every push / PR to `main` | Debug APK in **Actions → Artifacts** |
| `Release — Build & Publish APK` | tag `v*` or **Actions → Run workflow** | Installable Release APK in **Releases** + Artifacts |

```bash
git tag v1.0.0 && git push origin v1.0.0   # publishes a Release with the APK
```

### Production signing (optional)
Without a keystore, the release APK is **debug-signed** (installable, but not for Play Store).
Add these repo **Secrets** to sign with your own keystore: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.

## Project structure

```
app/src/main/java/com/liquidglass/notes/
├── MainActivity.kt          # edge-to-edge + navigation
├── GlassNotesApp.kt         # manual DI (repository, preferences)
├── data/                    # Note, NoteDao, Room DB, Repository, DataStore prefs
└── ui/
    ├── theme/               # iOS colours, typography, Material3 theme
    ├── components/Glass.kt  # liquidGlass modifier + animated blurred background
    ├── home/                # glass header, search, filters, staggered grid / list
    ├── editor/              # autosave editor, checklist, palette, reminders, share
    ├── library/             # Archive & Trash
    └── settings/            # theme, sort, layout, stats
.github/workflows/           # android.yml (CI) + release.yml (Release APK)
```

---

## 🇮🇷 راهنمای فارسی

**Liquid Notes** یه دفترچه یادداشت مینیمال اندرویده با ظاهر iOS و افکت **Liquid Glass** (شیشه مات با بلور زنده)، کاملاً **Edge-to-Edge** و آفلاین.

**امکانات:** ساخت و ویرایش یادداشت با ذخیره خودکار، چک‌لیست با نوار پیشرفت، پین و علاقه‌مندی، رنگ‌بندی پاستلی، پوشه‌بندی، جستجو و فیلتر، مرتب‌سازی، حالت شبکه/لیست، آرشیو و سطل زباله با Undo و بازیابی، اشتراک‌گذاری و خروجی گرفتن از همه یادداشت‌ها، یادآور، تم تاریک/روشن، آمار یادداشت‌ها.

**دیپلوی روی گیت‌هاب:**
1. فایل زیپ رو آنزیپ کن و کنار اسکریپت `unzip-and-deploy` بذار و اجراش کن — یا داخل پوشه پروژه `./deploy-to-github.sh` رو اجرا کن.
2. اکشن **Android CI** با هر Push یه APK دیباگ می‌سازه (تو بخش Artifacts).
3. برای ریلیز: از تب Actions گزینه **Release — Build & Publish APK** رو Run کن، یا تگ بزن: `git tag v1.0.0 && git push origin v1.0.0` — فایل APK توی بخش **Releases** منتشر می‌شه.
4. APK رو روی گوشی اندروید ۱۲ به بالا نصب کن و لذت ببر 🚀

**نیازمندی بیلد:** JDK 17 — روی گیت‌هاب اکشن همه‌چیز خودکار نصب می‌شه و نیازی به نصب چیزی روی سیستم خودت نیست.
