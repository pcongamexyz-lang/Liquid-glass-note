package com.liquidglass.notes.ui.theme

import androidx.compose.ui.graphics.Color

// iOS-inspired palette
val IOSBlue = Color(0xFF0A84FF)
val IOSIndigo = Color(0xFF5E5CE6)
val IOSPurple = Color(0xFFBF5AF2)
val IOSPink = Color(0xFFFF375F)
val IOSMint = Color(0xFF63E6BE)
val IOSTeal = Color(0xFF40C8E0)

val LightBackground = Color(0xFFF2F2F7) // iOS systemGroupedBackground
val DarkBackground = Color(0xFF000000)

val LightGlass = Color(0xBFFFFFFF)   // 75% white
val DarkGlass = Color(0xB32C2C2E)    // 70% iOS secondary system bg
val LightGlassBorder = Color(0xFFFFFFFF)
val DarkGlassBorder = Color(0x33FFFFFF)

/** Soft pastel tints for note cards, light / dark variants. */
fun noteTint(index: Int, dark: Boolean): Color = when (index) {
    1 -> if (dark) Color(0xFF4A2C35) else Color(0xFFFFDDE1) // blush
    2 -> if (dark) Color(0xFF4A3626) else Color(0xFFFFE8CC) // peach
    3 -> if (dark) Color(0xFF454021) else Color(0xFFFFF3BF) // lemon
    4 -> if (dark) Color(0xFF24403A) else Color(0xFFD3F9D8) // mint
    5 -> if (dark) Color(0xFF263A4A) else Color(0xFFD0EBFF) // sky
    6 -> if (dark) Color(0xFF382A4A) else Color(0xFFE5DBFF) // lavender
    7 -> if (dark) Color(0xFF472631) else Color(0xFFFFC9D6) // rose
    else -> if (dark) Color(0xFF2C2C2E) else Color(0xFFFFFFFF) // glass / white
}

val PaletteDots = listOf(
    Color(0xFFFFFFFF), Color(0xFFFF8FA3), Color(0xFFFFB26B), Color(0xFFFFD93D),
    Color(0xFF6BCB77), Color(0xFF4D96FF), Color(0xFF9B5DE5), Color(0xFFF15BB5)
)
