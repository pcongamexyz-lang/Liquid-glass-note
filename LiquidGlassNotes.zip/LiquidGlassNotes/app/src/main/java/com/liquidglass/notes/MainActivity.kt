package com.liquidglass.notes

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.liquidglass.notes.data.SortMode
import com.liquidglass.notes.data.ThemeMode
import com.liquidglass.notes.data.ViewMode
import com.liquidglass.notes.ui.components.CleanBackground
import com.liquidglass.notes.ui.editor.EditorScreen
import com.liquidglass.notes.ui.editor.EditorViewModel
import com.liquidglass.notes.ui.home.HomeScreen
import com.liquidglass.notes.ui.home.HomeViewModel
import com.liquidglass.notes.ui.library.LibraryScreen
import com.liquidglass.notes.ui.settings.SettingsScreen
import com.liquidglass.notes.ui.theme.LiquidGlassTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge() // full edge-to-edge: content draws behind status + navigation bars
        val app = application as GlassNotesApp

        setContent {
            val themeMode by app.preferences.themeMode.collectAsState(ThemeMode.SYSTEM)
            val sortMode by app.preferences.sortMode.collectAsState(SortMode.UPDATED)
            val viewMode by app.preferences.viewMode.collectAsState(ViewMode.GRID)
            val allNotes by app.repository.allNotes.collectAsState(emptyList())
            val scope = rememberCoroutineScope()
            val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
            LaunchedEffect(Unit) {
                if (Build.VERSION.SDK_INT >= 33) {
                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }

            LiquidGlassTheme(mode = themeMode) {
                val systemDark = isSystemInDarkTheme()
                val dark = when (themeMode) {
                    ThemeMode.SYSTEM -> systemDark
                    ThemeMode.LIGHT -> false
                    ThemeMode.DARK -> true
                }
                Surface(modifier = Modifier.fillMaxSize(), color = Color.Transparent) {
                    CleanBackground {
                        val nav = rememberNavController()
                        val homeVm: HomeViewModel = viewModel(factory = HomeViewModel.Factory(app))
                        val importMessageState by homeVm.importMessage.collectAsState()

                        NavHost(navController = nav, startDestination = "home") {
                            composable("home") {
                                HomeScreen(
                                    viewModel = homeVm,
                                    viewMode = viewMode,
                                    dark = dark,
                                    onOpenNote = { id -> nav.navigate("editor/$id") },
                                    onNewNote = { nav.navigate("editor/0") },
                                    onOpenLibrary = { isTrash -> nav.navigate(if (isTrash) "trash" else "archive") },
                                    onOpenSettings = { nav.navigate("settings") },
                                    onToggleView = {
                                        scope.launch {
                                            app.preferences.setView(if (viewMode == ViewMode.GRID) ViewMode.LIST else ViewMode.GRID)
                                        }
                                    }
                                )
                            }
                            composable(
                                "editor/{id}",
                                arguments = listOf(navArgument("id") { type = NavType.LongType })
                            ) { entry ->
                                val id = entry.arguments?.getLong("id") ?: 0L
                                val editorVm: EditorViewModel = viewModel(
                                    key = "editor-$id",
                                    factory = EditorViewModel.Factory(app, id)
                                )
                                EditorScreen(viewModel = editorVm, dark = dark, onBack = { nav.popBackStack() })
                            }
                            composable("archive") {
                                LibraryScreen(
                                    allNotes = allNotes, isTrash = false, dark = dark,
                                    onBack = { nav.popBackStack() },
                                    onRestore = { homeVm.restore(it) },
                                    onDeleteForever = { homeVm.deleteForever(it) },
                                    onEmptyTrash = { homeVm.emptyTrash() }
                                )
                            }
                            composable("trash") {
                                LibraryScreen(
                                    allNotes = allNotes, isTrash = true, dark = dark,
                                    onBack = { nav.popBackStack() },
                                    onRestore = { homeVm.restore(it) },
                                    onDeleteForever = { homeVm.deleteForever(it) },
                                    onEmptyTrash = { homeVm.emptyTrash() }
                                )
                            }
                            composable("settings") {
                                SettingsScreen(
                                    themeMode = themeMode, sortMode = sortMode, viewMode = viewMode,
                                    allNotes = allNotes, dark = dark,
                                    onTheme = { scope.launch { app.preferences.setTheme(it) } },
                                    onSort = { scope.launch { app.preferences.setSort(it) } },
                                    onView = { scope.launch { app.preferences.setView(it) } },
                                    onBack = { nav.popBackStack() },
                                    onExportBackup = {
                                        val json = com.liquidglass.notes.data.Backup.export(allNotes)
                                        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                            type = "application/json"
                                            putExtra(android.content.Intent.EXTRA_SUBJECT, "Liquid Notes backup")
                                            putExtra(android.content.Intent.EXTRA_TEXT, json)
                                        }
                                        startActivity(android.content.Intent.createChooser(intent, "Export backup"))
                                    },
                                    onImportBackup = { json -> homeVm.importBackup(json) },
                                    importMessage = importMessageState
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
