package com.liquidglass.notes.data

import org.json.JSONArray
import org.json.JSONObject

/** Full backup / restore of the library as a single JSON document (org.json, no extra deps). */
object Backup {
    fun export(notes: List<Note>): String {
        val array = JSONArray()
        notes.filter { !it.isTrashed }.forEach { n ->
            array.put(JSONObject().apply {
                put("title", n.title)
                put("content", n.content)
                put("isChecklist", n.isChecklist)
                put("color", n.color)
                put("category", n.category)
                put("isPinned", n.isPinned)
                put("isFavorite", n.isFavorite)
                put("isArchived", n.isArchived)
                put("isLocked", n.isLocked)
                n.reminderAt?.let { put("reminderAt", it) }
                put("createdAt", n.createdAt)
                put("updatedAt", n.updatedAt)
            })
        }
        return JSONObject().apply {
            put("app", "LiquidNotes")
            put("version", 1)
            put("notes", array)
        }.toString(2)
    }

    /** Returns the parsed notes (with fresh ids), or empty list if the JSON is invalid. */
    fun parse(json: String): List<Note> = runCatching {
        val root = JSONObject(json)
        val array = root.optJSONArray("notes") ?: return emptyList()
        val out = mutableListOf<Note>()
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            out += Note(
                title = o.optString("title"),
                content = o.optString("content"),
                isChecklist = o.optBoolean("isChecklist"),
                color = o.optInt("color"),
                category = o.optString("category", "Personal"),
                isPinned = o.optBoolean("isPinned"),
                isFavorite = o.optBoolean("isFavorite"),
                isArchived = o.optBoolean("isArchived"),
                isLocked = o.optBoolean("isLocked"),
                reminderAt = if (o.has("reminderAt")) o.optLong("reminderAt") else null,
                createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
            )
        }
        out
    }.getOrDefault(emptyList())
}
