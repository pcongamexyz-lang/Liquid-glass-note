package com.liquidglass.notes.ui.editor

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.liquidglass.notes.GlassNotesApp
import com.liquidglass.notes.data.Note
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class EditorViewModel(private val app: GlassNotesApp, private val noteId: Long) : ViewModel() {
    private val _note = MutableStateFlow<Note?>(if (noteId == 0L) Note() else null)
    val note: StateFlow<Note?> = _note.asStateFlow()
    private var loaded = noteId == 0L

    init {
        if (noteId != 0L) {
            viewModelScope.launch {
                _note.value = app.repository.getById(noteId) ?: Note()
                loaded = true
            }
        }
    }

    fun update(transform: (Note) -> Note) {
        val current = _note.value ?: return
        _note.value = transform(current)
    }

    /** Autosave: call on every change (debounced by the screen) and on exit. */
    fun save() {
        if (!loaded) return
        val current = _note.value ?: return
        if (current.title.isBlank() && current.plainText().isBlank()) {
            // Don't persist empty new notes; delete an emptied existing note softly via caller.
            if (current.id != 0L) viewModelScope.launch { app.repository.delete(current) }
            return
        }
        viewModelScope.launch {
            if (current.id == 0L) {
                val id = app.repository.insert(current)
                _note.value = current.copy(id = id)
            } else {
                app.repository.update(current)
            }
        }
    }

    fun deleteToTrash() {
        val current = _note.value ?: return
        if (current.id == 0L) return
        viewModelScope.launch { app.repository.update(current.copy(isTrashed = true, isPinned = false)) }
    }

    fun duplicate() {
        val current = _note.value ?: return
        if (current.id == 0L) return
        viewModelScope.launch { app.repository.duplicate(current) }
    }

    class Factory(private val app: GlassNotesApp, private val noteId: Long) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = EditorViewModel(app, noteId) as T
    }
}
