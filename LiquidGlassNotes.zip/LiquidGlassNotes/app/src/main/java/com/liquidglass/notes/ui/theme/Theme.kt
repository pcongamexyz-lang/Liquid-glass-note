package com.liquidglass.notes.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.liquidglass.notes.data.ThemeMode

private val LightScheme = lightColorScheme(
    primary = IOSBlue, secondary = IOSIndigo, tertiary = IOSPurple,
    background = LightBackground, surface = Color.White,
    onBackground = Color(0xFF1C1C1E), onSurface = Color(0xFF1C1C1E),
    surfaceVariant = Color(0xFFE5E5EA), outline = Color(0xFFC7C7CC)
)
private val DarkScheme = darkColorScheme(
    primary = IOSBlue, secondary = IOSIndigo, tertiary = IOSPurple,
    background = DarkBackground, surface = Color(0xFF1C1C1E),
    onBackground = Color.White, onSurface = Color.White,
    surfaceVariant = Color(0xFF2C2C2E), outline = Color(0xFF48484A)
)

@Composable
fun LiquidGlassTheme(mode: ThemeMode = ThemeMode.SYSTEM, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        typography = AppTypography,
        content = content
    )
}

@Composable
fun isDarkTheme(): Boolean = MaterialTheme.colorScheme.background == DarkBackground
