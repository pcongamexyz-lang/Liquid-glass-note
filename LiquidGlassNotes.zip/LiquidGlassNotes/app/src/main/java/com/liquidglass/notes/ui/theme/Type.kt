package com.liquidglass.notes.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// SF-like: system sans, tight large titles like iOS
val AppTypography = Typography(
    displaySmall = TextStyle(FontFamily.SansSerif, FontWeight.Bold, 34.sp, 40.sp, letterSpacing = (-0.5).sp),
    headlineMedium = TextStyle(FontFamily.SansSerif, FontWeight.Bold, 28.sp, 34.sp, letterSpacing = (-0.4).sp),
    titleLarge = TextStyle(FontFamily.SansSerif, FontWeight.SemiBold, 20.sp, 26.sp),
    titleMedium = TextStyle(FontFamily.SansSerif, FontWeight.SemiBold, 17.sp, 22.sp),
    bodyLarge = TextStyle(FontFamily.SansSerif, FontWeight.Normal, 17.sp, 24.sp),
    bodyMedium = TextStyle(FontFamily.SansSerif, FontWeight.Normal, 15.sp, 21.sp),
    bodySmall = TextStyle(FontFamily.SansSerif, FontWeight.Normal, 13.sp, 18.sp),
    labelMedium = TextStyle(FontFamily.SansSerif, FontWeight.Medium, 12.sp, 16.sp),
    labelSmall = TextStyle(FontFamily.SansSerif, FontWeight.Medium, 11.sp, 14.sp)
)
