package com.liquidglass.notes.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// SF-like: system sans, tight large titles like iOS.
// NOTE: TextStyle must be built with NAMED arguments — its first positional
// parameter is `color`, not fontFamily (positional calls fail to compile).
private fun style(
    weight: FontWeight,
    size: Int,
    lineHeight: Int,
    letterSpacing: Float = 0f
) = TextStyle(
    fontFamily = FontFamily.SansSerif,
    fontWeight = weight,
    fontSize = size.sp,
    lineHeight = lineHeight.sp,
    letterSpacing = letterSpacing.sp
)

val AppTypography = Typography(
    displaySmall = style(FontWeight.Bold, 34, 40, -0.5f),
    headlineMedium = style(FontWeight.Bold, 28, 34, -0.4f),
    titleLarge = style(FontWeight.SemiBold, 20, 26),
    titleMedium = style(FontWeight.SemiBold, 17, 22),
    bodyLarge = style(FontWeight.Normal, 17, 24),
    bodyMedium = style(FontWeight.Normal, 15, 21),
    bodySmall = style(FontWeight.Normal, 13, 18),
    labelMedium = style(FontWeight.Medium, 12, 16),
    labelSmall = style(FontWeight.Medium, 11, 14)
)
