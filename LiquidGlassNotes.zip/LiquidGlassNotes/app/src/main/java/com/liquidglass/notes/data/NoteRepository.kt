package com.liquidglass.notes.data

import kotlinx.coroutines.flow.Flow

class NoteRepository(private val dao: NoteDao) {
    val allNotes: Flow<List<Note>> = dao.observeAll()
    fun observeById(id: Long): Flow<Note?> = dao.observeById(id)
    suspend fun getById(id: Long): Note? = dao.getById(id)
    suspend fun insert(note: Note): Long = dao.insert(note)
    suspend fun update(note: Note) = dao.update(note.copy(updatedAt = System.currentTimeMillis()))
    suspend fun delete(note: Note) = dao.delete(note)
    suspend fun emptyTrash() = dao.emptyTrash()

    suspend fun duplicate(note: Note): Long = dao.insert(
        note.copy(
            id = 0,
            title = if (note.title.isBlank()) "Copy" else "${note.title} copy",
            isPinned = false,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
    )
}
