package com.liquidglass.notes

import android.app.Application
import com.liquidglass.notes.data.AppDatabase
import com.liquidglass.notes.data.AppPreferences
import com.liquidglass.notes.data.NoteRepository

/** Manual DI — keeps the build simple, fast and dependency-light. */
class GlassNotesApp : Application() {
    lateinit var repository: NoteRepository
        private set
    lateinit var preferences: AppPreferences
        private set

    override fun onCreate() {
        super.onCreate()
        repository = NoteRepository(AppDatabase.get(this).noteDao())
        preferences = AppPreferences(this)
    }
}
