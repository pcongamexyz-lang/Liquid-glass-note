package com.liquidglass.notes.ui.library

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.liquidglass.notes.data.Note
import com.liquidglass.notes.ui.components.liquidGlass
import com.liquidglass.notes.ui.components.liveGlass
import com.liquidglass.notes.ui.theme.noteTint
import dev.chrisbanes.haze.hazeSource
import dev.chrisbanes.haze.rememberHazeState

/** Archive or Trash list with restore / delete-forever actions. */
@Composable
fun LibraryScreen(
    allNotes: List<Note>,
    isTrash: Boolean,
    dark: Boolean,
    onBack: () -> Unit,
    onRestore: (Note) -> Unit,
    onDeleteForever: (Note) -> Unit,
    onEmptyTrash: () -> Unit
) {
    var confirmEmpty by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf<Note?>(null) }
    val hazeState = rememberHazeState()
    val notes = allNotes.filter { if (isTrash) it.isTrashed else (it.isArchived && !it.isTrashed) }

    Box(Modifier.fillMaxSize()) {
        // Content (blur source)
        if (notes.isEmpty()) {
            Box(Modifier.fillMaxSize().hazeSource(hazeState), contentAlignment = Alignment.Center) {
                Text(if (isTrash) "Trash is empty" else "Nothing archived yet", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize().hazeSource(hazeState),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 96.dp, bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(notes, key = { it.id }, contentType = { "note" }) { note ->
                    Box(
                        Modifier.fillMaxWidth()
                            .background(noteTint(note.color, dark).copy(alpha = if (dark) 0.75f else 0.55f), RoundedCornerShape(24.dp))
                            .liquidGlass(RoundedCornerShape(24.dp), dark, alpha = 0.30f)
                            .padding(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(note.title.ifBlank { "Untitled" }, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(note.plainText(), style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                            }
                            IconButton(onClick = { onRestore(note) }) { Icon(Icons.Filled.Restore, "Restore") }
                            if (isTrash) {
                                IconButton(onClick = { confirmDelete = note }) { Icon(Icons.Filled.DeleteForever, "Delete forever") }
                            }
                        }
                    }
                }
            }
        }

        // Floating LIVE-BLUR header
        Box(
            Modifier.align(Alignment.TopCenter).statusBarsPadding()
                .padding(horizontal = 16.dp).padding(top = 8.dp)
                .fillMaxWidth().liveGlass(hazeState, dark, RoundedCornerShape(28.dp))
        ) {
            Row(Modifier.padding(horizontal = 6.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                Text(if (isTrash) "Trash" else "Archive", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                if (isTrash && notes.isNotEmpty()) {
                    TextButton(onClick = { confirmEmpty = true }) { Text("Empty trash") }
                }
            }
        }
    }
    if (confirmEmpty) {
        AlertDialog(
            onDismissRequest = { confirmEmpty = false },
            title = { Text("Empty trash?") },
            text = { Text("All trashed notes will be permanently deleted.") },
            confirmButton = { TextButton(onClick = { confirmEmpty = false; onEmptyTrash() }) { Text("Delete all") } },
            dismissButton = { TextButton(onClick = { confirmEmpty = false }) { Text("Cancel") } }
        )
    }
    val target = confirmDelete
    if (target != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Delete forever?") },
            text = { Text("This cannot be undone.") },
            confirmButton = { TextButton(onClick = { confirmDelete = null; onDeleteForever(target) }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } }
        )
    }
}
