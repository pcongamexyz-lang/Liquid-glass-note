package com.liquidglass.notes.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class SortMode { UPDATED, CREATED, TITLE }
enum class ViewMode { GRID, LIST }

private val Context.dataStore by preferencesDataStore(name = "settings")

class AppPreferences(private val context: Context) {
    private object Keys {
        val THEME = stringPreferencesKey("theme_mode")
        val SORT = stringPreferencesKey("sort_mode")
        val VIEW = stringPreferencesKey("view_mode")
        val SEED = intPreferencesKey("seeded_v1")
    }

    val themeMode: Flow<ThemeMode> = context.dataStore.data.map {
        runCatching { ThemeMode.valueOf(it[Keys.THEME] ?: "SYSTEM") }.getOrDefault(ThemeMode.SYSTEM)
    }
    val sortMode: Flow<SortMode> = context.dataStore.data.map {
        runCatching { SortMode.valueOf(it[Keys.SORT] ?: "UPDATED") }.getOrDefault(SortMode.UPDATED)
    }
    val viewMode: Flow<ViewMode> = context.dataStore.data.map {
        runCatching { ViewMode.valueOf(it[Keys.VIEW] ?: "GRID") }.getOrDefault(ViewMode.GRID)
    }
    val seeded: Flow<Boolean> = context.dataStore.data.map { (it[Keys.SEED] ?: 0) == 1 }

    suspend fun setTheme(value: ThemeMode) = context.dataStore.edit { it[Keys.THEME] = value.name }
    suspend fun setSort(value: SortMode) = context.dataStore.edit { it[Keys.SORT] = value.name }
    suspend fun setView(value: ViewMode) = context.dataStore.edit { it[Keys.VIEW] = value.name }
    suspend fun markSeeded() = context.dataStore.edit { it[Keys.SEED] = 1 }
}
