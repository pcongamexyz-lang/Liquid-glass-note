package com.liquidglass.notes.ui.editor

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liquidglass.notes.data.Categories
import com.liquidglass.notes.data.ChecklistItem
import com.liquidglass.notes.data.Note
import com.liquidglass.notes.ui.components.liquidGlass
import com.liquidglass.notes.ui.theme.PaletteDots
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun EditorScreen(viewModel: EditorViewModel, dark: Boolean, onBack: () -> Unit) {
    val note by viewModel.note.collectAsState()
    val context = LocalContext.current
    var showDelete by remember { mutableStateOf(false) }
    var showReminder by remember { mutableStateOf(false) }
    var showCategory by remember { mutableStateOf(false) }

    // Autosave (debounced)
    LaunchedEffect(note) {
        if (note != null) { delay(700); viewModel.save() }
    }

    val current = note
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(8.dp))
        // Glass toolbar
        Box(Modifier.fillMaxWidth().liquidGlass(RoundedCornerShape(28.dp), dark)) {
            Row(Modifier.padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { viewModel.save(); onBack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                Spacer(Modifier.weight(1f))
                if (current != null) {
                    IconButton(onClick = { viewModel.update { it.copy(isPinned = !it.isPinned) } }) {
                        Icon(if (current.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin, "Pin")
                    }
                    IconButton(onClick = { viewModel.update { it.copy(isFavorite = !it.isFavorite) } }) {
                        Icon(if (current.isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Favourite", tint = if (current.isFavorite) Color(0xFFFF375F) else MaterialTheme.colorScheme.onSurface)
                    }
                    IconButton(onClick = { viewModel.update { it.copy(isChecklist = !it.isChecklist, content = convertChecklist(it)) } }) {
                        Icon(Icons.Filled.Checklist, "Toggle checklist", tint = if (current.isChecklist) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    }
                    IconButton(onClick = { showReminder = true }) { Icon(Icons.Filled.Alarm, "Reminder") }
                    IconButton(onClick = {
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, current.title)
                            putExtra(Intent.EXTRA_TEXT, "${current.title}\n\n${current.plainText()}")
                        }
                        context.startActivity(Intent.createChooser(intent, "Share note"))
                    }) { Icon(Icons.Filled.Share, "Share") }
                    IconButton(onClick = { viewModel.duplicate() }) { Icon(Icons.Filled.ContentCopy, "Duplicate") }
                    IconButton(onClick = { showDelete = true }) { Icon(Icons.Filled.Delete, "Delete") }
                }
            }
        }

        if (current == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Loading…") }
        } else {
        Spacer(Modifier.height(10.dp))
        // Category + palette row
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box {
                FilterChip(selected = true, onClick = { showCategory = true }, label = { Text(current.category) })
                DropdownMenu(expanded = showCategory, onDismissRequest = { showCategory = false }) {
                    Categories.all.forEach { cat ->
                        DropdownMenuItem(text = { Text(cat) }, onClick = { viewModel.update { it.copy(category = cat) }; showCategory = false })
                    }
                }
            }
            PaletteDots.forEachIndexed { index, color ->
                Box(
                    Modifier.size(28.dp).clip(CircleShape).background(color)
                        .border(if (current.color == index) 3.dp else 1.dp, if (current.color == index) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.4f), CircleShape)
                        .clickable { viewModel.update { it.copy(color = index) } }
                )
            }
        }
        if (current.reminderAt != null) {
            Spacer(Modifier.height(8.dp))
            Text(
                "⏰ Reminder: ${SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(current.reminderAt))}  (tap ✕ to clear)",
                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.clickable { viewModel.update { it.copy(reminderAt = null) } }
            )
        }

        Spacer(Modifier.height(6.dp))
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            TextField(
                value = current.title,
                onValueChange = { v -> viewModel.update { it.copy(title = v) } },
                placeholder = { Text("Title", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f)) },
                textStyle = MaterialTheme.typography.headlineMedium, singleLine = false,
                modifier = Modifier.fillMaxWidth(),
                colors = transparentFieldColors()
            )
            Text(
                "${SimpleDateFormat("MMMM d, yyyy 'at' HH:mm", Locale.getDefault()).format(Date(current.updatedAt))}  •  ${current.wordCount} words",
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(Modifier.height(6.dp))
            if (current.isChecklist) {
                ChecklistEditor(current) { items -> viewModel.update { it.copy(content = Note.encodeChecklist(items)) } }
            } else {
                TextField(
                    value = current.content,
                    onValueChange = { v -> viewModel.update { it.copy(content = v) } },
                    placeholder = { Text("Start writing…") },
                    textStyle = TextStyle(fontSize = 17.sp, lineHeight = 25.sp),
                    modifier = Modifier.fillMaxWidth().height(520.dp),
                    colors = transparentFieldColors()
                )
            }
        }
        } // close else (current != null)
    }

    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("Move to trash?") },
            text = { Text("You can restore this note from Trash.") },
            confirmButton = { TextButton(onClick = { showDelete = false; viewModel.deleteToTrash(); onBack() }) { Text("Move to trash") } },
            dismissButton = { TextButton(onClick = { showDelete = false }) { Text("Cancel") } }
        )
    }
    if (showReminder) {
        val now = System.currentTimeMillis()
        AlertDialog(
            onDismissRequest = { showReminder = false },
            title = { Text("Set reminder") },
            text = {
                Column {
                    listOf("In 1 hour" to now + 3_600_000L, "Tomorrow morning" to now + 86_400_000L, "In 1 week" to now + 604_800_000L).forEach { (label, at) ->
                        TextButton(onClick = { viewModel.update { it.copy(reminderAt = at) }; showReminder = false }) { Text(label) }
                    }
                    if (current?.reminderAt != null) TextButton(onClick = { viewModel.update { it.copy(reminderAt = null) }; showReminder = false }) { Text("Remove reminder") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showReminder = false }) { Text("Cancel") } }
        )
    }
}

private fun convertChecklist(note: Note): String =
    if (!note.isChecklist) {
        // turning checklist ON: plain lines -> unchecked items
        Note.encodeChecklist(note.content.lines().filter { it.isNotBlank() }.map { ChecklistItem(false, it.trim()) }.ifEmpty { listOf(ChecklistItem(false, "")) })
    } else {
        // turning OFF: items -> plain lines
        note.checklistItems().joinToString("\n") { it.text }
    }

@Composable
private fun transparentFieldColors() = TextFieldDefaults.colors(
    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
    disabledIndicatorColor = Color.Transparent
)

@Composable
private fun ChecklistEditor(note: Note, onChange: (List<ChecklistItem>) -> Unit) {
    val items = remember(note.id) { mutableStateListOf<ChecklistItem>().apply { addAll(note.checklistItems()) } }
    // Keep VM in sync when initial load arrives
    LaunchedEffect(note.checklistItems().size) {
        if (items.isEmpty() && note.checklistItems().isNotEmpty()) { items.addAll(note.checklistItems()) }
    }
    fun sync() { onChange(items.toList()) }
    Column(Modifier.padding(horizontal = 8.dp)) {
        items.forEachIndexed { index, item ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = item.checked, onCheckedChange = { c -> items[index] = item.copy(checked = c); sync() })
                TextField(
                    value = item.text,
                    onValueChange = { v -> items[index] = item.copy(text = v); sync() },
                    placeholder = { Text("Item") }, singleLine = true,
                    modifier = Modifier.weight(1f), colors = transparentFieldColors()
                )
                IconButton(onClick = { if (items.size > 1) items.removeAt(index); sync() }) {
                    Icon(Icons.Filled.Delete, "Remove item")
                }
            }
        }
        TextButton(onClick = { items.add(ChecklistItem(false, "")); sync() }) {
            Text("+  Add item", fontWeight = FontWeight.SemiBold)
        }
        val done = items.count { it.checked }
        Text("$done of ${items.size} done", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f), modifier = Modifier.padding(start = 12.dp))
    }
}
