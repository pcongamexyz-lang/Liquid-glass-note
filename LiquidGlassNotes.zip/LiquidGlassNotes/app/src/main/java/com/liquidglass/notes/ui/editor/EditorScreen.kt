package com.liquidglass.notes.ui.editor

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.FormatStrikethrough
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liquidglass.notes.data.Categories
import com.liquidglass.notes.data.ChecklistItem
import com.liquidglass.notes.data.Note
import com.liquidglass.notes.ui.components.blurSource
import com.liquidglass.notes.ui.components.liveGlass
import com.liquidglass.notes.ui.theme.PaletteDots
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun EditorScreen(viewModel: EditorViewModel, dark: Boolean, onBack: () -> Unit) {
    val note by viewModel.note.collectAsState()
    val context = LocalContext.current
    val hazeState = remember { HazeState() }
    var showDelete by remember { mutableStateOf(false) }
    var showReminder by remember { mutableStateOf(false) }
    var showCategory by remember { mutableStateOf(false) }
    var preview by remember { mutableStateOf(false) }

    // ---- Rich body state (selection-aware) with grouped undo/redo ----
    var body by remember { mutableStateOf(TextFieldValue("")) }
    var lastSynced by remember { mutableStateOf("") }
    val undoStack = remember { mutableStateListOf<TextFieldValue>() }
    val redoStack = remember { mutableStateListOf<TextFieldValue>() }
    var lastPushAt by remember { mutableStateOf(0L) }

    LaunchedEffect(note) { if (note != null) { delay(700); viewModel.save() } }

    val current = note

    LaunchedEffect(current?.id, current?.content) {
        val c = current ?: return@LaunchedEffect
        if (!c.isChecklist && c.content != body.text && c.content != lastSynced) {
            body = TextFieldValue(c.content, TextRange(c.content.length))
            lastSynced = c.content
        }
    }

    fun applyBody(new: TextFieldValue, record: Boolean = true) {
        val now = System.currentTimeMillis()
        if (record && new.text != body.text && (now - lastPushAt > 1200 || undoStack.isEmpty())) {
            undoStack.add(body); if (undoStack.size > 60) undoStack.removeAt(0)
            redoStack.clear(); lastPushAt = now
        }
        body = new; lastSynced = new.text
        viewModel.update { it.copy(content = new.text) }
    }
    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.add(body)
        val v = undoStack.removeAt(undoStack.lastIndex)
        body = v; lastSynced = v.text
        viewModel.update { it.copy(content = v.text) }
    }
    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.add(body)
        val v = redoStack.removeAt(redoStack.lastIndex)
        body = v; lastSynced = v.text
        viewModel.update { it.copy(content = v.text) }
    }
    fun wrap(prefix: String, suffix: String = prefix) {
        val sel = body.selection
        val start = minOf(sel.start, sel.end); val end = maxOf(sel.start, sel.end)
        val selected = body.text.substring(start, end)
        val newText = body.text.substring(0, start) + prefix + selected + suffix + body.text.substring(end)
        val newSel = if (selected.isEmpty()) TextRange(start + prefix.length)
            else TextRange(start + prefix.length, start + prefix.length + selected.length)
        applyBody(TextFieldValue(newText, newSel))
    }
    fun linePrefix(prefix: String) {
        val cursor = minOf(body.selection.start, body.selection.end)
        val lineStart = body.text.lastIndexOf('\n', (cursor - 1).coerceAtLeast(0)) + 1
        val newText = body.text.substring(0, lineStart) + prefix + body.text.substring(lineStart)
        applyBody(TextFieldValue(newText, TextRange(cursor + prefix.length)))
    }
    fun insertAtCursor(insert: String) {
        val sel = body.selection
        val start = minOf(sel.start, sel.end); val end = maxOf(sel.start, sel.end)
        val newText = body.text.substring(0, start) + insert + body.text.substring(end)
        applyBody(TextFieldValue(newText, TextRange(start + insert.length)))
    }

    Box(Modifier.fillMaxSize()) {

        // ---- Content layer (blur source) ----
        if (current == null) {
            Box(Modifier.fillMaxSize().blurSource(hazeState), contentAlignment = Alignment.Center) { Text("Loading…") }
        } else {
            Column(
                Modifier.fillMaxSize().blurSource(hazeState)
                    .statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp)
            ) {
                Spacer(Modifier.height(76.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box {
                        FilterChip(selected = true, onClick = { showCategory = true }, label = { Text(current.category) })
                        DropdownMenu(expanded = showCategory, onDismissRequest = { showCategory = false }) {
                            Categories.all.forEach { cat ->
                                DropdownMenuItem(text = { Text(cat) }, onClick = { viewModel.update { it.copy(category = cat) }; showCategory = false })
                            }
                        }
                    }
                    PaletteDots.forEachIndexed { index, color ->
                        Box(
                            Modifier.size(28.dp).clip(CircleShape).background(color)
                                .border(if (current.color == index) 3.dp else 1.dp, if (current.color == index) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.4f), CircleShape)
                                .clickable { viewModel.update { it.copy(color = index) } }
                        )
                    }
                }
                if (current.reminderAt != null) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "⏰ Reminder: ${SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(current.reminderAt))}  (tap to clear)",
                        style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.clickable { viewModel.update { it.copy(reminderAt = null) } }
                    )
                }
                Spacer(Modifier.height(6.dp))
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    TextField(
                        value = current.title,
                        onValueChange = { v -> viewModel.update { it.copy(title = v) } },
                        placeholder = { Text("Title", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f)) },
                        textStyle = MaterialTheme.typography.headlineMedium, singleLine = false,
                        modifier = Modifier.fillMaxWidth(),
                        colors = transparentFieldColors()
                    )
                    Text(
                        "${SimpleDateFormat("MMMM d, yyyy 'at' HH:mm", Locale.getDefault()).format(Date(current.updatedAt))}  •  ${current.wordCount} words",
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    Spacer(Modifier.height(6.dp))
                    when {
                        current.isChecklist -> ChecklistEditor(current) { items -> viewModel.update { it.copy(content = Note.encodeChecklist(items)) } }
                        preview -> MarkdownPreview(current.content, Modifier.fillMaxWidth().padding(horizontal = 12.dp).padding(bottom = 120.dp))
                        else -> TextField(
                            value = body,
                            onValueChange = { applyBody(it) },
                            placeholder = { Text("Start writing…  Tip: use #tag anywhere") },
                            textStyle = TextStyle(fontSize = 17.sp, lineHeight = 25.sp),
                            modifier = Modifier.fillMaxWidth().height(520.dp),
                            colors = transparentFieldColors()
                        )
                    }
                    Spacer(Modifier.height(120.dp))
                }
            }
        }

        // ---- Floating LIVE-BLUR toolbar (top) ----
        Box(
            Modifier.align(Alignment.TopCenter).statusBarsPadding()
                .padding(horizontal = 16.dp).padding(top = 8.dp)
                .fillMaxWidth().liveGlass(hazeState, dark, RoundedCornerShape(28.dp))
        ) {
            Row(Modifier.padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { viewModel.save(); onBack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                Spacer(Modifier.weight(1f))
                if (current != null) {
                    IconButton(onClick = { viewModel.update { it.copy(isPinned = !it.isPinned) } }) {
                        Icon(if (current.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin, "Pin")
                    }
                    IconButton(onClick = { viewModel.update { it.copy(isFavorite = !it.isFavorite) } }) {
                        Icon(if (current.isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Favourite", tint = if (current.isFavorite) Color(0xFFFF375F) else MaterialTheme.colorScheme.onSurface)
                    }
                    IconButton(onClick = { viewModel.update { it.copy(isLocked = !it.isLocked) } }) {
                        Icon(if (current.isLocked) Icons.Filled.Lock else Icons.Filled.LockOpen, "Lock (hides content in lists)", tint = if (current.isLocked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    }
                    IconButton(onClick = { preview = !preview }) {
                        Icon(if (preview) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, "Markdown preview", tint = if (preview) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    }
                    IconButton(onClick = { viewModel.update { it.copy(isChecklist = !it.isChecklist, content = convertChecklist(it)) } }) {
                        Icon(Icons.Filled.Checklist, "Toggle checklist", tint = if (current.isChecklist) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    }
                    IconButton(onClick = { showReminder = true }) { Icon(Icons.Filled.Alarm, "Reminder") }
                    IconButton(onClick = {
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, current.title)
                            putExtra(Intent.EXTRA_TEXT, "${current.title}\n\n${current.plainText()}")
                        }
                        context.startActivity(Intent.createChooser(intent, "Share note"))
                    }) { Icon(Icons.Filled.Share, "Share") }
                    IconButton(onClick = { viewModel.duplicate() }) { Icon(Icons.Filled.ContentCopy, "Duplicate") }
                    IconButton(onClick = { showDelete = true }) { Icon(Icons.Filled.Delete, "Delete") }
                }
            }
        }

        // ---- Floating LIVE-BLUR formatting bar (bottom) ----
        if (current != null && !current.isChecklist && !preview) {
            Box(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding()
                    .padding(horizontal = 16.dp).padding(bottom = 10.dp)
                    .liveGlass(hazeState, dark, RoundedCornerShape(26.dp))
            ) {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FormatButton(Icons.AutoMirrored.Filled.Undo, "Undo", undoStack.isNotEmpty()) { undo() }
                    FormatButton(Icons.AutoMirrored.Filled.Redo, "Redo", redoStack.isNotEmpty()) { redo() }
                    FormatButton(Icons.Filled.FormatBold, "Bold") { wrap("**") }
                    FormatButton(Icons.Filled.FormatItalic, "Italic") { wrap("*") }
                    FormatButton(Icons.Filled.FormatStrikethrough, "Strikethrough") { wrap("~~") }
                    TextButton(onClick = { linePrefix("# ") }) { Text("H1", fontWeight = FontWeight.Bold) }
                    TextButton(onClick = { linePrefix("## ") }) { Text("H2", fontWeight = FontWeight.Bold) }
                    FormatButton(Icons.Filled.FormatListBulleted, "Bullet list") { linePrefix("- ") }
                    FormatButton(Icons.Filled.Checklist, "Task item") { linePrefix("- [ ] ") }
                    FormatButton(Icons.Filled.FormatQuote, "Quote") { linePrefix("> ") }
                    FormatButton(Icons.Filled.Remove, "Divider") { insertAtCursor("\n\n---\n\n") }
                    TextButton(onClick = { insertAtCursor(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())) }) { Text("Date") }
                    TextButton(onClick = { wrap("`") }) { Text("Code", fontWeight = FontWeight.Bold) }
                }
            }
        }
    }

    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("Move to trash?") },
            text = { Text("You can restore this note from Trash.") },
            confirmButton = { TextButton(onClick = { showDelete = false; viewModel.deleteToTrash(); onBack() }) { Text("Move to trash") } },
            dismissButton = { TextButton(onClick = { showDelete = false }) { Text("Cancel") } }
        )
    }
    if (showReminder) {
        val now = System.currentTimeMillis()
        AlertDialog(
            onDismissRequest = { showReminder = false },
            title = { Text("Set reminder") },
            text = {
                Column {
                    Text("You'll get a real notification at this time.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                    listOf("In 1 hour" to now + 3_600_000L, "Tomorrow morning" to now + 86_400_000L, "In 1 week" to now + 604_800_000L).forEach { (label, at) ->
                        TextButton(onClick = { viewModel.update { it.copy(reminderAt = at) }; showReminder = false }) { Text(label) }
                    }
                    if (current?.reminderAt != null) TextButton(onClick = { viewModel.update { it.copy(reminderAt = null) }; showReminder = false }) { Text("Remove reminder") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showReminder = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun FormatButton(icon: ImageVector, label: String, enabled: Boolean = true, onClick: () -> Unit) {
    IconButton(onClick = onClick, enabled = enabled, modifier = Modifier.size(42.dp)) {
        Icon(icon, label, Modifier.size(21.dp), tint = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f))
    }
}

private fun convertChecklist(note: Note): String =
    if (!note.isChecklist) {
        Note.encodeChecklist(note.content.lines().filter { it.isNotBlank() }.map { ChecklistItem(false, it.trim()) }.ifEmpty { listOf(ChecklistItem(false, "")) })
    } else {
        note.checklistItems().joinToString("\n") { it.text }
    }

@Composable
private fun transparentFieldColors() = TextFieldDefaults.colors(
    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
    disabledIndicatorColor = Color.Transparent
)

@Composable
private fun ChecklistEditor(note: Note, onChange: (List<ChecklistItem>) -> Unit) {
    val items = remember(note.id) { mutableStateListOf<ChecklistItem>().apply { addAll(note.checklistItems()) } }
    LaunchedEffect(note.checklistItems().size) {
        if (items.isEmpty() && note.checklistItems().isNotEmpty()) { items.addAll(note.checklistItems()) }
    }
    fun sync() { onChange(items.toList()) }
    Column(Modifier.padding(horizontal = 8.dp)) {
        items.forEachIndexed { index, item ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = item.checked, onCheckedChange = { c -> items[index] = item.copy(checked = c); sync() })
                TextField(
                    value = item.text,
                    onValueChange = { v -> items[index] = item.copy(text = v); sync() },
                    placeholder = { Text("Item") }, singleLine = true,
                    modifier = Modifier.weight(1f), colors = transparentFieldColors()
                )
                IconButton(onClick = { if (items.size > 1) items.removeAt(index); sync() }) {
                    Icon(Icons.Filled.Delete, "Remove item")
                }
            }
        }
        TextButton(onClick = { items.add(ChecklistItem(false, "")); sync() }) {
            Text("+  Add item", fontWeight = FontWeight.SemiBold)
        }
        val done = items.count { it.checked }
        Text("$done of ${items.size} done", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f), modifier = Modifier.padding(start = 12.dp))
    }
}
