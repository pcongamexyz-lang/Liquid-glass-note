package com.liquidglass.notes.data

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.liquidglass.notes.MainActivity
import java.util.concurrent.TimeUnit

/** Real reminder notifications, scheduled with WorkManager. */
object Reminders {
    const val CHANNEL_ID = "note_reminders"

    fun createChannel(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Reminders", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "Notifications for note reminders"
                }
            )
        }
    }

    fun schedule(context: Context, note: Note) {
        val at = note.reminderAt ?: return cancel(context, note.id)
        val delay = at - System.currentTimeMillis()
        if (delay <= 0 || note.isTrashed) return cancel(context, note.id)
        val request = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("title" to note.title.ifBlank { "Note reminder" }, "noteId" to note.id))
            .addTag("reminder_${note.id}")
            .build()
        WorkManager.getInstance(context)
            .enqueueUniqueWork("reminder_${note.id}", ExistingWorkPolicy.REPLACE, request)
    }

    fun cancel(context: Context, noteId: Long) {
        WorkManager.getInstance(context).cancelUniqueWork("reminder_$noteId")
    }
}

class ReminderWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val title = inputData.getString("title") ?: "Note reminder"
        val noteId = inputData.getLong("noteId", 0L)
        Reminders.createChannel(applicationContext)

        val intent = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(
            applicationContext, noteId.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(applicationContext, Reminders.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText("⏰ Reminder from Liquid Notes")
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        try {
            NotificationManagerCompat.from(applicationContext).notify(noteId.toInt(), notification)
        } catch (_: SecurityException) {
            // Notification permission not granted — nothing more we can do.
        }
        return Result.success()
    }
}
