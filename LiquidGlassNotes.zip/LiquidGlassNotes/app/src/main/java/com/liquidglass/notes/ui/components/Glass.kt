package com.liquidglass.notes.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.liquidglass.notes.ui.theme.DarkGlass
import com.liquidglass.notes.ui.theme.DarkGlassBorder
import com.liquidglass.notes.ui.theme.LightGlass
import com.liquidglass.notes.ui.theme.LightGlassBorder
import dev.chrisbanes.haze.ExperimentalHazeApi
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.haze
import dev.chrisbanes.haze.hazeChild

/**
 * Clean, flat background — Craft-style. No gradients, no colour blobs,
 * no animations (which also keeps the app light on battery/GPU).
 * Live blur lives only on headers/toolbars via [liveGlass].
 */
@Composable
fun CleanBackground(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        content()
    }
}

/** Translucent tint + bright 1dp edge + soft shadow (the glass material itself). */
fun Modifier.liquidGlass(
    shape: Shape = RoundedCornerShape(24.dp),
    dark: Boolean,
    alpha: Float = 1f
): Modifier =
    this
        .shadow(10.dp, shape, clip = false, ambientColor = Color.Black.copy(alpha = 0.06f), spotColor = Color.Black.copy(alpha = 0.10f))
        .clip(shape)
        .background(if (dark) DarkGlass.copy(alpha = DarkGlass.alpha * alpha) else LightGlass.copy(alpha = LightGlass.alpha * alpha))
        .border(1.dp, if (dark) DarkGlassBorder else LightGlassBorder, shape)

/** Mark the scrolling content as the source that headers will blur. (Haze 1.1.1 API) */
fun Modifier.blurSource(state: HazeState): Modifier = this.haze(state)

/**
 * LIVE blur glass for headers/toolbars: really blurs whatever scrolls
 * underneath (the content must be marked with [blurSource]), finished
 * with a thin translucent tint. Keep this on small surfaces only —
 * headers, search bar, docks — for performance. (Haze 1.1.1 API:
 * hazeChild + HazeMaterials; there is no hazeEffect in this version.)
 */
@OptIn(ExperimentalHazeApi::class)
@Composable
fun Modifier.liveGlass(
    hazeState: HazeState,
    dark: Boolean,
    shape: Shape = RoundedCornerShape(28.dp)
): Modifier {
    // Strong, clearly visible frost — the library's ultraThin preset is far
    // too subtle on a light background, so we use a custom style instead:
    // big blur radius + a real tint over the blurred content (iOS-like).
    val style = dev.chrisbanes.haze.HazeStyle(
        backgroundColor = if (dark) Color(0xFF101012) else Color(0xFFF4F4F8),
        tints = listOf(
            dev.chrisbanes.haze.HazeTint(
                if (dark) Color(0xFF2A2A2E).copy(alpha = 0.55f) else Color.White.copy(alpha = 0.48f)
            )
        ),
        blurRadius = 28.dp,
        noiseFactor = 0.04f
    )
    return this
        .hazeChild(state = hazeState, shape = shape, style = style)
        .liquidGlass(shape = shape, dark = dark, alpha = 0.22f)
}
