package com.liquidglass.notes.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.liquidglass.notes.ui.theme.DarkGlass
import com.liquidglass.notes.ui.theme.DarkGlassBorder
import com.liquidglass.notes.ui.theme.LightGlass
import com.liquidglass.notes.ui.theme.LightGlassBorder

/** Liquid Glass surface: translucent fill + bright 1dp edge + soft shadow.
 *  Real backdrop blur comes from [LiquidBackground] blobs behind it. */
fun Modifier.liquidGlass(shape: Shape = RoundedCornerShape(24.dp), dark: Boolean, alpha: Float = 1f): Modifier =
    this
        .shadow(12.dp, shape, clip = false, ambientColor = Color.Black.copy(alpha = 0.08f), spotColor = Color.Black.copy(alpha = 0.12f))
        .clip(shape)
        .background(if (dark) DarkGlass.copy(alpha = DarkGlass.alpha * alpha) else LightGlass.copy(alpha = LightGlass.alpha * alpha))
        .border(1.dp, if (dark) DarkGlassBorder else LightGlassBorder, shape)

/** Animated aurora background — big coloured blobs blurred hard = iOS wallpaper glass feel. */
@Composable
fun LiquidBackground(content: @Composable () -> Unit) {
    val dark = MaterialTheme.colorScheme.background == Color.Black
    val transition = rememberInfiniteTransition(label = "aurora")
    val drift by transition.animateFloat(
        initialValue = -30f, targetValue = 30f,
        animationSpec = infiniteRepeatable(tween(9000), RepeatMode.Reverse), label = "drift"
    )
    val drift2 by transition.animateFloat(
        initialValue = 25f, targetValue = -25f,
        animationSpec = infiniteRepeatable(tween(11000), RepeatMode.Reverse), label = "drift2"
    )
    Box(
        Modifier.fillMaxSize().background(
            if (dark) Brush.verticalGradient(listOf(Color(0xFF0B0B12), Color(0xFF000000)))
            else Brush.verticalGradient(listOf(Color(0xFFF7F7FC), Color(0xFFEFF2FF)))
        )
    ) {
        val blobAlpha = if (dark) 0.45f else 0.55f
        Box(Modifier.offset(x = (-60 + drift).dp, y = (-40).dp).size(300.dp).blur(90.dp)
            .background(Color(0xFF7A9CFF).copy(alpha = blobAlpha), CircleShape))
        Box(Modifier.offset(x = 220.dp, y = (120 + drift2).dp).size(280.dp).blur(100.dp)
            .background(Color(0xFFFF8FAB).copy(alpha = blobAlpha * 0.8f), CircleShape))
        Box(Modifier.offset(x = (-40 + drift2).dp, y = 480.dp).size(320.dp).blur(110.dp)
            .background(Color(0xFF63E6BE).copy(alpha = blobAlpha * 0.7f), CircleShape))
        Box(Modifier.offset(x = 240.dp, y = 640.dp).size(240.dp).blur(90.dp)
            .background(Color(0xFFBF5AF2).copy(alpha = blobAlpha * 0.55f), CircleShape))
        content()
    }
}

/** Frosted pill/bar used for top bars, search and the floating dock. */
@Composable
fun GlassBar(modifier: Modifier = Modifier, dark: Boolean, shape: Shape = RoundedCornerShape(28.dp), content: @Composable () -> Unit) {
    Box(modifier.liquidGlass(shape = shape, dark = dark)) { content() }
}
