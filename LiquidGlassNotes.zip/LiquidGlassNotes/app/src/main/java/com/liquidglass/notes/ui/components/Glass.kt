package com.liquidglass.notes.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.liquidglass.notes.ui.theme.DarkGlass
import com.liquidglass.notes.ui.theme.DarkGlassBorder
import com.liquidglass.notes.ui.theme.LightGlass
import com.liquidglass.notes.ui.theme.LightGlassBorder
import dev.chrisbanes.haze.ExperimentalHazeApi
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.haze
import dev.chrisbanes.haze.hazeChild
import dev.chrisbanes.haze.materials.ExperimentalHazeMaterialsApi
import dev.chrisbanes.haze.materials.HazeMaterials

/**
 * Clean, flat background — Craft-style. No gradients, no colour blobs,
 * no animations (which also keeps the app light on battery/GPU).
 * Live blur lives only on headers/toolbars via [liveGlass].
 */
@Composable
fun CleanBackground(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        content()
    }
}

/** Translucent tint + bright 1dp edge + soft shadow (the glass material itself). */
fun Modifier.liquidGlass(
    shape: Shape = RoundedCornerShape(24.dp),
    dark: Boolean,
    alpha: Float = 1f
): Modifier =
    this
        .shadow(10.dp, shape, clip = false, ambientColor = Color.Black.copy(alpha = 0.06f), spotColor = Color.Black.copy(alpha = 0.10f))
        .clip(shape)
        .background(if (dark) DarkGlass.copy(alpha = DarkGlass.alpha * alpha) else LightGlass.copy(alpha = LightGlass.alpha * alpha))
        .border(1.dp, if (dark) DarkGlassBorder else LightGlassBorder, shape)

/** Mark the scrolling content as the source that headers will blur. (Haze 1.1.1 API) */
fun Modifier.blurSource(state: HazeState): Modifier = this.haze(state)

/**
 * LIVE blur glass for headers/toolbars: really blurs whatever scrolls
 * underneath (the content must be marked with [blurSource]), finished
 * with a thin translucent tint. Keep this on small surfaces only —
 * headers, search bar, docks — for performance. (Haze 1.1.1 API:
 * hazeChild + HazeMaterials; there is no hazeEffect in this version.)
 */
@OptIn(ExperimentalHazeApi::class, ExperimentalHazeMaterialsApi::class)
@Composable
fun Modifier.liveGlass(
    hazeState: HazeState,
    dark: Boolean,
    shape: Shape = RoundedCornerShape(28.dp)
): Modifier =
    this
        .hazeChild(state = hazeState, shape = shape, style = HazeMaterials.ultraThin())
        .liquidGlass(shape = shape, dark = dark, alpha = 0.45f)
