package com.liquidglass.notes.ui.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.liquidglass.notes.data.Note
import com.liquidglass.notes.data.SortMode
import com.liquidglass.notes.data.ThemeMode
import com.liquidglass.notes.data.ViewMode
import com.liquidglass.notes.ui.components.liquidGlass

@Composable
fun SettingsScreen(
    themeMode: ThemeMode,
    sortMode: SortMode,
    viewMode: ViewMode,
    allNotes: List<Note>,
    dark: Boolean,
    onTheme: (ThemeMode) -> Unit,
    onSort: (SortMode) -> Unit,
    onView: (ViewMode) -> Unit,
    onBack: () -> Unit
) {
    val totalWords = allNotes.filter { !it.isTrashed }.sumOf { it.wordCount }
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth().liquidGlass(RoundedCornerShape(28.dp), dark)) {
            Row(Modifier.padding(horizontal = 6.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                Text("Settings", style = MaterialTheme.typography.titleLarge)
            }
        }
        Spacer(Modifier.height(16.dp))

        Section("Appearance", dark) {
            Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                ThemeMode.entries.forEach { mode ->
                    FilterChip(selected = themeMode == mode, onClick = { onTheme(mode) }, label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) })
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Section("Default sort", dark) {
            Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                SortMode.entries.forEach { mode ->
                    FilterChip(selected = sortMode == mode, onClick = { onSort(mode) }, label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) })
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Section("Layout", dark) {
            Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                ViewMode.entries.forEach { mode ->
                    FilterChip(selected = viewMode == mode, onClick = { onView(mode) }, label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) })
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Section("Your library", dark) {
            Column(Modifier.padding(4.dp)) {
                Stat("Total notes", allNotes.count { !it.isTrashed }.toString())
                Stat("Pinned", allNotes.count { it.isPinned && !it.isTrashed }.toString())
                Stat("Favourites", allNotes.count { it.isFavorite && !it.isTrashed }.toString())
                Stat("Archived", allNotes.count { it.isArchived && !it.isTrashed }.toString())
                Stat("In trash", allNotes.count { it.isTrashed }.toString())
                Stat("Total words", totalWords.toString())
            }
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "Liquid Notes 1.0.0\nMinimal, offline-first, no account, no tracking.\nYour notes never leave this device unless you share them.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            modifier = Modifier.padding(horizontal = 8.dp)
        )
    }
}

@Composable
private fun Section(title: String, dark: Boolean, content: @Composable () -> Unit) {
    Box(Modifier.fillMaxWidth().liquidGlass(RoundedCornerShape(24.dp), dark)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
        Text(value, style = MaterialTheme.typography.titleMedium)
    }
}
