package com.liquidglass.notes.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.liquidglass.notes.data.Note
import com.liquidglass.notes.data.SortMode
import com.liquidglass.notes.data.ThemeMode
import com.liquidglass.notes.data.ViewMode
import com.liquidglass.notes.ui.components.liquidGlass
import com.liquidglass.notes.ui.components.liveGlass
import com.liquidglass.notes.ui.components.blurSource
import dev.chrisbanes.haze.HazeState

@Composable
fun SettingsScreen(
    themeMode: ThemeMode,
    sortMode: SortMode,
    viewMode: ViewMode,
    allNotes: List<Note>,
    dark: Boolean,
    onTheme: (ThemeMode) -> Unit,
    onSort: (SortMode) -> Unit,
    onView: (ViewMode) -> Unit,
    onBack: () -> Unit,
    onExportBackup: () -> Unit = {},
    onImportBackup: (String) -> Unit = {},
    importMessage: String? = null
) {
    var showImport by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var importText by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
    val hazeState = remember { HazeState() }
    val totalWords = remember(allNotes) { allNotes.filter { !it.isTrashed }.sumOf { it.wordCount } }

    Box(Modifier.fillMaxSize()) {
        // Content (blur source)
        Column(
            Modifier.fillMaxSize().blurSource(hazeState)
                .statusBarsPadding().padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(Modifier.height(84.dp)) // room for the floating header

            Section("Appearance", dark) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.entries.forEach { mode ->
                        FilterChip(selected = themeMode == mode, onClick = { onTheme(mode) }, label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) })
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Section("Default sort", dark) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SortMode.entries.forEach { mode ->
                        FilterChip(selected = sortMode == mode, onClick = { onSort(mode) }, label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) })
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Section("Layout", dark) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ViewMode.entries.forEach { mode ->
                        FilterChip(selected = viewMode == mode, onClick = { onView(mode) }, label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) })
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Section("Backup & restore", dark) {
                Column(Modifier.padding(4.dp)) {
                    Text(
                        "Export a full JSON backup of every note, or restore one. Backups include colours, folders, checklists, locks and reminders.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        androidx.compose.material3.Button(onClick = onExportBackup) { Text("Export backup") }
                        androidx.compose.material3.OutlinedButton(onClick = { showImport = true }) { Text("Import backup") }
                    }
                    if (importMessage != null) {
                        Spacer(Modifier.height(8.dp))
                        Text(importMessage, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Section("Your library", dark) {
                Column(Modifier.padding(4.dp)) {
                    Stat("Total notes", allNotes.count { !it.isTrashed }.toString())
                    Stat("Pinned", allNotes.count { it.isPinned && !it.isTrashed }.toString())
                    Stat("Favourites", allNotes.count { it.isFavorite && !it.isTrashed }.toString())
                    Stat("Archived", allNotes.count { it.isArchived && !it.isTrashed }.toString())
                    Stat("In trash", allNotes.count { it.isTrashed }.toString())
                    Stat("Total words", totalWords.toString())
                }
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "Liquid Notes 1.2.0\nMinimal, offline-first, no account, no tracking.\nYour notes never leave this device unless you share them.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                modifier = Modifier.padding(horizontal = 8.dp)
            )
            Spacer(Modifier.height(32.dp))
        }

        // Floating LIVE-BLUR header
        Box(
            Modifier.align(Alignment.TopCenter).statusBarsPadding()
                .padding(horizontal = 16.dp).padding(top = 8.dp)
                .fillMaxWidth().liveGlass(hazeState, dark, RoundedCornerShape(28.dp))
        ) {
            Row(Modifier.padding(horizontal = 6.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                Text("Settings", style = MaterialTheme.typography.titleLarge)
            }
        }
    }

    if (showImport) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showImport = false },
            title = { Text("Import backup") },
            text = {
                Column {
                    Text("Paste a Liquid Notes backup JSON below. Notes are added as new copies — nothing is overwritten.", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(10.dp))
                    androidx.compose.material3.OutlinedTextField(
                        value = importText, onValueChange = { importText = it },
                        placeholder = { Text("{ \"app\": \"LiquidNotes\", \"notes\": [ ... ] }") },
                        modifier = Modifier.fillMaxWidth().height(160.dp)
                    )
                }
            },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = { showImport = false; onImportBackup(importText); importText = "" }) { Text("Import") }
            },
            dismissButton = { androidx.compose.material3.TextButton(onClick = { showImport = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun Section(title: String, dark: Boolean, content: @Composable () -> Unit) {
    Box(Modifier.fillMaxWidth().liquidGlass(RoundedCornerShape(24.dp), dark)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
        Text(value, style = MaterialTheme.typography.titleMedium)
    }
}
