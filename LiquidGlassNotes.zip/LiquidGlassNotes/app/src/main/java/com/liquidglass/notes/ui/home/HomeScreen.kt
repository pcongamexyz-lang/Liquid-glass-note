package com.liquidglass.notes.ui.home

import android.content.Intent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.liquidglass.notes.data.Categories
import com.liquidglass.notes.data.Note
import com.liquidglass.notes.data.SortMode
import com.liquidglass.notes.data.ViewMode
import com.liquidglass.notes.ui.components.liquidGlass
import com.liquidglass.notes.ui.components.liveGlass
import com.liquidglass.notes.ui.theme.noteTint
import dev.chrisbanes.haze.hazeSource
import dev.chrisbanes.haze.rememberHazeState
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val HeaderHeight = 232.dp

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    viewMode: ViewMode,
    dark: Boolean,
    onOpenNote: (Long) -> Unit,
    onNewNote: () -> Unit,
    onOpenLibrary: (Boolean) -> Unit,
    onOpenSettings: () -> Unit,
    onToggleView: () -> Unit
) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val hazeState = rememberHazeState()
    var sortMenu by remember { mutableStateOf(false) }
    var mainMenu by remember { mutableStateOf(false) }
    var exportConfirm by remember { mutableStateOf(false) }

    fun share(note: Note) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, note.title)
            putExtra(Intent.EXTRA_TEXT, "${note.title}\n\n${note.plainText()}")
        }
        context.startActivity(Intent.createChooser(intent, "Share note"))
    }
    fun exportAll() {
        val text = state.notes.joinToString("\n\n---\n\n") { "# ${it.title}\n${it.plainText()}" }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "Liquid Notes export")
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(intent, "Export all notes"))
    }
    fun onTrashed(note: Note) {
        scope.launch {
            val r = snackbar.showSnackbar("Note moved to trash", "Undo")
            if (r == SnackbarResult.ActionPerformed) viewModel.restore(note)
        }
    }

    Scaffold(
        containerColor = Color.Transparent,
        snackbarHost = { SnackbarHost(snackbar) },
        floatingActionButton = {
            // Minimal monochrome FAB (Craft-style): black on light, white on dark
            FloatingActionButton(
                onClick = onNewNote, shape = CircleShape,
                containerColor = MaterialTheme.colorScheme.onSurface,
                elevation = FloatingActionButtonDefaults.elevation(8.dp),
                modifier = Modifier.size(60.dp)
            ) { Icon(Icons.Filled.Add, "New note", Modifier.size(28.dp), tint = MaterialTheme.colorScheme.surface) }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {

            // ---- Content layer (the blur source: headers blur THIS) ----
            if (state.notes.isEmpty()) {
                Box(Modifier.fillMaxSize().hazeSource(hazeState), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = HeaderHeight)) {
                        Text("🍃", style = MaterialTheme.typography.displaySmall)
                        Spacer(Modifier.height(10.dp))
                        Text("No notes here yet", style = MaterialTheme.typography.titleLarge)
                        Text("Tap + and write your first thought.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    }
                }
            } else if (viewMode == ViewMode.GRID) {
                LazyVerticalStaggeredGrid(
                    columns = StaggeredGridCells.Fixed(2),
                    modifier = Modifier.fillMaxSize().hazeSource(hazeState),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = HeaderHeight, bottom = 96.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp), verticalItemSpacing = 12.dp
                ) {
                    items(state.notes, key = { it.id }, contentType = { "note" }) { note ->
                        NoteCard(note, dark, onOpenNote, viewModel, ::share, ::onTrashed)
                    }
                }
            } else {
                LazyColumn(
                    Modifier.fillMaxSize().hazeSource(hazeState),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = HeaderHeight, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(state.notes, key = { it.id }, contentType = { "note" }) { note ->
                        NoteCard(note, dark, onOpenNote, viewModel, ::share, ::onTrashed)
                    }
                }
            }

            // ---- Floating layer: LIVE-BLUR header + search + filters ----
            Column(Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(horizontal = 16.dp)) {
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().liveGlass(hazeState, dark, RoundedCornerShape(28.dp))) {
                    Row(Modifier.padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Notes", style = MaterialTheme.typography.displaySmall)
                            Text("${state.totalCount} notes", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                        }
                        Box {
                            IconButton(onClick = { sortMenu = true }) { Icon(Icons.Filled.Sort, "Sort") }
                            DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                                DropdownMenuItem(text = { Text("Recently edited") }, onClick = { viewModel.setSort(SortMode.UPDATED); sortMenu = false })
                                DropdownMenuItem(text = { Text("Recently created") }, onClick = { viewModel.setSort(SortMode.CREATED); sortMenu = false })
                                DropdownMenuItem(text = { Text("Title A–Z") }, onClick = { viewModel.setSort(SortMode.TITLE); sortMenu = false })
                            }
                        }
                        IconButton(onClick = onToggleView) {
                            Icon(if (viewMode == ViewMode.GRID) Icons.Filled.ViewAgenda else Icons.Filled.GridView, "Toggle view")
                        }
                        Box {
                            IconButton(onClick = { mainMenu = true }) { Icon(Icons.Filled.MoreVert, "Menu") }
                            DropdownMenu(expanded = mainMenu, onDismissRequest = { mainMenu = false }) {
                                DropdownMenuItem(text = { Text("Archive") }, leadingIcon = { Icon(Icons.Filled.Archive, null) }, onClick = { mainMenu = false; onOpenLibrary(false) })
                                DropdownMenuItem(text = { Text("Trash") }, leadingIcon = { Icon(Icons.Filled.DeleteSweep, null) }, onClick = { mainMenu = false; onOpenLibrary(true) })
                                DropdownMenuItem(text = { Text("Export all notes") }, leadingIcon = { Icon(Icons.Filled.Share, null) }, onClick = { mainMenu = false; exportConfirm = true })
                                DropdownMenuItem(text = { Text("Settings") }, leadingIcon = { Icon(Icons.Filled.Settings, null) }, onClick = { mainMenu = false; onOpenSettings() })
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Box(Modifier.fillMaxWidth().liveGlass(hazeState, dark, RoundedCornerShape(24.dp))) {
                    TextField(
                        value = state.query, onValueChange = viewModel::setQuery,
                        placeholder = { Text("Search notes") },
                        leadingIcon = { Icon(Icons.Filled.Search, null) },
                        singleLine = true, modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
                        )
                    )
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = state.filter == QuickFilter.ALL && state.category == null, onClick = { viewModel.setFilter(QuickFilter.ALL); viewModel.setCategory(null) }, label = { Text("All") })
                    FilterChip(selected = state.filter == QuickFilter.PINNED, onClick = { viewModel.setFilter(QuickFilter.PINNED) }, label = { Text("Pinned") })
                    FilterChip(selected = state.filter == QuickFilter.FAVORITES, onClick = { viewModel.setFilter(QuickFilter.FAVORITES) }, label = { Text("Favourites") })
                    Categories.all.forEach { cat ->
                        FilterChip(selected = state.category == cat, onClick = { viewModel.setCategory(if (state.category == cat) null else cat); viewModel.setFilter(QuickFilter.ALL) }, label = { Text(cat) })
                    }
                }
            }
        }
    }
    if (exportConfirm) {
        AlertDialog(
            onDismissRequest = { exportConfirm = false },
            title = { Text("Export all notes?") },
            text = { Text("All visible notes will be shared as one text document.") },
            confirmButton = { TextButton(onClick = { exportConfirm = false; exportAll() }) { Text("Export") } },
            dismissButton = { TextButton(onClick = { exportConfirm = false }) { Text("Cancel") } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun NoteCard(
    note: Note, dark: Boolean, onOpen: (Long) -> Unit,
    viewModel: HomeViewModel, onShare: (Note) -> Unit, onTrashed: (Note) -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val dateFormat = remember { SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()) }
    val tint = noteTint(note.color, dark)
    Box(
        Modifier.fillMaxWidth()
            .background(tint.copy(alpha = if (dark) 0.75f else 0.55f), RoundedCornerShape(24.dp))
            .liquidGlass(RoundedCornerShape(24.dp), dark, alpha = 0.30f)
            .combinedClickable(onClick = { onOpen(note.id) }, onLongClick = { menu = true })
            .padding(16.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.Top) {
                Text(
                    note.title.ifBlank { "Untitled" }, style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (note.isPinned) Icon(Icons.Filled.PushPin, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                if (note.isFavorite) Icon(Icons.Filled.Favorite, null, Modifier.size(16.dp), tint = Color(0xFFFF375F))
            }
            if (note.isChecklist) {
                val (done, total) = note.checklistProgress()
                Spacer(Modifier.height(8.dp))
                note.checklistItems().take(4).forEach { item ->
                    Text((if (item.checked) "☑  " else "☐  ") + item.text, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (total > 0) {
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(progress = { done.toFloat() / total }, modifier = Modifier.fillMaxWidth())
                    Text("$done of $total done", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                }
            } else if (note.content.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(note.plainText(), style = MaterialTheme.typography.bodySmall, maxLines = 6, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f))
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(dateFormat.format(Date(note.updatedAt)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
                Spacer(Modifier.width(8.dp))
                Text(note.category, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                if (note.reminderAt != null) Text("  •  ⏰", style = MaterialTheme.typography.labelSmall)
            }
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(text = { Text(if (note.isPinned) "Unpin" else "Pin") }, leadingIcon = { Icon(Icons.Outlined.PushPin, null) }, onClick = { menu = false; viewModel.togglePin(note) })
            DropdownMenuItem(text = { Text(if (note.isFavorite) "Remove favourite" else "Favourite") }, leadingIcon = { Icon(if (note.isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null) }, onClick = { menu = false; viewModel.toggleFavorite(note) })
            DropdownMenuItem(text = { Text("Share") }, onClick = { menu = false; onShare(note) })
            DropdownMenuItem(text = { Text("Duplicate") }, onClick = { menu = false; viewModel.duplicate(note) })
            DropdownMenuItem(text = { Text("Archive") }, onClick = { menu = false; viewModel.archive(note) })
            DropdownMenuItem(text = { Text("Move to trash") }, onClick = { menu = false; confirmDelete = true })
        }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Move to trash?") },
            text = { Text("You can restore it from Trash, or undo right after.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; viewModel.trash(note); onTrashed(note) }) { Text("Move") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}
