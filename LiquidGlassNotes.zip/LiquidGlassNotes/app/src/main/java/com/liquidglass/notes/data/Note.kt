package com.liquidglass.notes.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Note colours — soft iOS pastel tints (index into NotePalette). */
object NotePalette {
    const val GLASS = 0
    const val BLUSH = 1
    const val PEACH = 2
    const val LEMON = 3
    const val MINT = 4
    const val SKY = 5
    const val LAVENDER = 6
    const val ROSE = 7
    const val COUNT = 8
}

object Categories {
    val all = listOf("Personal", "Work", "Ideas", "Study", "Shopping", "Travel", "Other")
}

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    /** Plain text body, or checklist payload when [isChecklist] is true.
     *  Checklist payload format: one item per line -> "1|Done item" / "0|Open item" */
    val content: String = "",
    val isChecklist: Boolean = false,
    val color: Int = NotePalette.GLASS,
    val category: String = "Personal",
    val isPinned: Boolean = false,
    val isFavorite: Boolean = false,
    val isLocked: Boolean = false,
    val isArchived: Boolean = false,
    val isTrashed: Boolean = false,
    val reminderAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val wordCount: Int
        get() = plainText().split(Regex("\\s+")).count { it.isNotBlank() }

    fun plainText(): String =
        if (!isChecklist) content
        else content.lines().map { it.substringAfter('|', it) }.joinToString("\n")

    fun checklistItems(): List<ChecklistItem> =
        if (content.isBlank()) emptyList()
        else content.lines().filter { it.isNotBlank() }.map { line ->
            ChecklistItem(checked = line.startsWith("1|"), text = line.substringAfter('|', line))
        }

    /** Hashtags (#tag) found in title + body, lowercased, de-duplicated. */
    fun tags(): List<String> =
        Regex("#([\\p{L}0-9_]+)").findAll("$title\n${plainText()}")
            .map { it.groupValues[1].lowercase() }
            .distinct()
            .toList()

    fun checklistProgress(): Pair<Int, Int> {
        val items = checklistItems()
        return items.count { it.checked } to items.size
    }

    companion object {
        fun encodeChecklist(items: List<ChecklistItem>): String =
            items.joinToString("\n") { "${if (it.checked) 1 else 0}|${it.text.replace("\n", " ")}" }
    }
}

data class ChecklistItem(val checked: Boolean = false, val text: String = "")
