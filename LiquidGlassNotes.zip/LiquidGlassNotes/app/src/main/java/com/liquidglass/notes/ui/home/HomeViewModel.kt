package com.liquidglass.notes.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.liquidglass.notes.GlassNotesApp
import com.liquidglass.notes.data.Note
import com.liquidglass.notes.data.SortMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class QuickFilter { ALL, PINNED, FAVORITES }

data class HomeUiState(
    val notes: List<Note> = emptyList(),
    val query: String = "",
    val category: String? = null,
    val filter: QuickFilter = QuickFilter.ALL,
    val sort: SortMode = SortMode.UPDATED,
    val totalCount: Int = 0,
    val tags: List<String> = emptyList(),
    val selectedTag: String? = null
)

class HomeViewModel(private val app: GlassNotesApp) : ViewModel() {
    private val query = MutableStateFlow("")
    private val category = MutableStateFlow<String?>(null)
    private val filter = MutableStateFlow(QuickFilter.ALL)
    private val selectedTag = MutableStateFlow<String?>(null)
    val importMessage = MutableStateFlow<String?>(null)

    val state: StateFlow<HomeUiState> = combine(
        app.repository.allNotes, query, category, filter, app.preferences.sortMode, selectedTag
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val notes = values[0] as List<Note>
        val q = values[1] as String
        val cat = values[2] as String?
        val f = values[3] as QuickFilter
        val sort = values[4] as SortMode
        val tag = values[5] as String?
        val active = notes.filter { !it.isArchived && !it.isTrashed }
        val allTags = active.flatMap { it.tags() }.groupingBy { it }.eachCount()
            .entries.sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            .map { it.key }.take(12)
        var list = active
        if (tag != null) list = list.filter { tag in it.tags() }
        if (cat != null) list = list.filter { it.category == cat }
        when (f) {
            QuickFilter.PINNED -> list = list.filter { it.isPinned }
            QuickFilter.FAVORITES -> list = list.filter { it.isFavorite }
            QuickFilter.ALL -> Unit
        }
        if (q.isNotBlank()) {
            val needle = q.trim().lowercase()
            list = list.filter {
                it.title.lowercase().contains(needle) ||
                    it.category.lowercase().contains(needle) ||
                    needle.removePrefix("#") in it.tags() ||
                    (!it.isLocked && it.plainText().lowercase().contains(needle))
            }
        }
        val sorted = when (sort) {
            SortMode.UPDATED -> list.sortedWith(compareByDescending<Note> { it.isPinned }.thenByDescending { it.updatedAt })
            SortMode.CREATED -> list.sortedWith(compareByDescending<Note> { it.isPinned }.thenByDescending { it.createdAt })
            SortMode.TITLE -> list.sortedWith(compareByDescending<Note> { it.isPinned }.thenBy { it.title.lowercase() })
        }
        HomeUiState(sorted, q, cat, f, sort, active.size, allTags, tag)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    init { seedIfNeeded() }

    private fun seedIfNeeded() {
        viewModelScope.launch {
            if (!app.preferences.seeded.first()) {
                val now = System.currentTimeMillis()
                app.repository.insert(Note(
                    title = "Welcome to Liquid Notes ✨",
                    content = "A minimal, iOS-style notepad with Liquid Glass.\n\n• Tap + to create a note\n• Pin, favourite, archive or colour your notes\n• Switch any note to a checklist\n• Search, filter by folder, sort and share\n• Everything works offline",
                    category = "Ideas", color = 5, isPinned = true, createdAt = now, updatedAt = now
                ))
                app.repository.insert(Note(
                    title = "Shopping list",
                    content = Note.encodeChecklist(listOf(
                        com.liquidglass.notes.data.ChecklistItem(true, "Coffee"),
                        com.liquidglass.notes.data.ChecklistItem(false, "Oat milk"),
                        com.liquidglass.notes.data.ChecklistItem(false, "Eggs"),
                        com.liquidglass.notes.data.ChecklistItem(false, "Sourdough bread")
                    )),
                    isChecklist = true, category = "Shopping", color = 4, createdAt = now, updatedAt = now
                ))
                app.preferences.markSeeded()
            }
        }
    }

    fun setQuery(v: String) { query.value = v }
    fun setCategory(v: String?) { category.value = v }
    fun setFilter(v: QuickFilter) { filter.value = v }
    fun setTag(v: String?) { selectedTag.value = v }

    fun archiveAll(notes: List<Note>) { notes.forEach { archive(it) } }
    fun trashAll(notes: List<Note>) { notes.forEach { trash(it) } }
    fun restoreAll(notes: List<Note>) { notes.forEach { restore(it) } }

    fun importBackup(json: String) {
        viewModelScope.launch {
            val parsed = com.liquidglass.notes.data.Backup.parse(json)
            if (parsed.isEmpty()) {
                importMessage.value = "Import failed — that doesn't look like a Liquid Notes backup."
            } else {
                app.repository.insertAll(parsed)
                parsed.forEach { if (it.reminderAt != null) com.liquidglass.notes.data.Reminders.schedule(app, it) }
                importMessage.value = "Imported ${parsed.size} notes from backup ✓"
            }
        }
    }
    fun setSort(v: SortMode) { viewModelScope.launch { app.preferences.setSort(v) } }

    fun togglePin(note: Note) = update(note.copy(isPinned = !note.isPinned))
    fun toggleFavorite(note: Note) = update(note.copy(isFavorite = !note.isFavorite))
    fun archive(note: Note) = update(note.copy(isArchived = true, isPinned = false))
    fun trash(note: Note) = update(note.copy(isTrashed = true, isPinned = false))
    fun restore(note: Note) = update(note.copy(isTrashed = false, isArchived = false))
    fun duplicate(note: Note) { viewModelScope.launch { app.repository.duplicate(note) } }
    fun deleteForever(note: Note) { viewModelScope.launch { app.repository.delete(note) } }
    fun emptyTrash() { viewModelScope.launch { app.repository.emptyTrash() } }
    private fun update(note: Note) { viewModelScope.launch { app.repository.update(note) } }

    class Factory(private val app: GlassNotesApp) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = HomeViewModel(app) as T
    }
}
