package com.liquidglass.notes.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp

/** Lightweight Markdown preview: headings, bullets, tasks, quotes, dividers + **bold**, *italic*, ~~strike~~, `code`. */
@Composable
fun MarkdownPreview(text: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        text.lines().forEach { raw ->
            val line = raw.trimEnd()
            when {
                line.isBlank() -> Spacer(Modifier.height(8.dp))
                line == "---" || line == "***" -> {
                    Spacer(Modifier.height(6.dp)); HorizontalDivider(); Spacer(Modifier.height(6.dp))
                }
                line.startsWith("### ") -> Text(inline(line.drop(4)), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(vertical = 3.dp))
                line.startsWith("## ") -> Text(inline(line.drop(3)), style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(vertical = 4.dp))
                line.startsWith("# ") -> Text(inline(line.drop(2)), style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(vertical = 5.dp))
                line.startsWith("- [ ] ") -> Text("☐  " + inline(line.drop(6)).text, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(vertical = 2.dp))
                line.startsWith("- [x] ") || line.startsWith("- [X] ") ->
                    Text(inline("☑  " + line.drop(6)), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f), modifier = Modifier.padding(vertical = 2.dp))
                line.startsWith("- ") || line.startsWith("* ") ->
                    Row(Modifier.padding(vertical = 2.dp)) {
                        Text("•  ", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.primary)
                        Text(inline(line.drop(2)), style = MaterialTheme.typography.bodyLarge)
                    }
                line.matches(Regex("^\\d+\\. .*")) ->
                    Text(inline(line), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(vertical = 2.dp))
                line.startsWith("> ") -> Row(Modifier.padding(vertical = 3.dp)) {
                    Box(Modifier.width(3.dp).height(22.dp).background(MaterialTheme.colorScheme.primary))
                    Spacer(Modifier.width(10.dp))
                    Text(inline(line.drop(2)), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f))
                }
                else -> Text(inline(line), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(vertical = 2.dp))
            }
        }
    }
}

/** Inline spans: **bold**, *italic*, ~~strike~~, `code`. Unmatched markers are left as-is. */
fun inline(text: String): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (i < text.length) {
        when {
            text.startsWith("**", i) -> {
                val end = text.indexOf("**", i + 2)
                if (end > i + 2) {
                    pushStyle(SpanStyle(fontWeight = FontWeight.Bold)); append(text.substring(i + 2, end)); pop()
                    i = end + 2
                } else { append("**"); i += 2 }
            }
            text.startsWith("~~", i) -> {
                val end = text.indexOf("~~", i + 2)
                if (end > i + 2) {
                    pushStyle(SpanStyle(textDecoration = TextDecoration.LineThrough)); append(text.substring(i + 2, end)); pop()
                    i = end + 2
                } else { append("~~"); i += 2 }
            }
            text.startsWith("*", i) -> {
                val end = text.indexOf("*", i + 1)
                if (end > i + 1) {
                    pushStyle(SpanStyle(fontStyle = FontStyle.Italic)); append(text.substring(i + 1, end)); pop()
                    i = end + 1
                } else { append("*"); i += 1 }
            }
            text.startsWith("`", i) -> {
                val end = text.indexOf("`", i + 1)
                if (end > i + 1) {
                    pushStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = Color(0x22808080))); append(text.substring(i + 1, end)); pop()
                    i = end + 1
                } else { append("`"); i += 1 }
            }
            else -> { append(text[i]); i += 1 }
        }
    }
}
