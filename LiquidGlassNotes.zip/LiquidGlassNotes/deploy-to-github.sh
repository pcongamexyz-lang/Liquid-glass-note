#!/usr/bin/env bash
# ============================================================
#  Liquid Notes — Deploy this project to GitHub & build APK
#  Usage:  ./deploy-to-github.sh [repo-name] [public|private]
#  Needs:  git + GitHub CLI (gh) -> https://cli.github.com
# ============================================================
set -euo pipefail
cd "$(dirname "$0")"

REPO_NAME="${1:-liquid-glass-notes}"
VISIBILITY="${2:-public}"

echo "🚀 Deploying Liquid Notes to GitHub as: $REPO_NAME ($VISIBILITY)"

command -v git >/dev/null || { echo "❌ git is not installed."; exit 1; }
if ! command -v gh >/dev/null; then
  echo "❌ GitHub CLI (gh) is not installed. Get it from https://cli.github.com"
  echo "   Or push manually:  git init && git add . && git commit -m init && git remote add origin <url> && git push -u origin main"
  exit 1
fi

gh auth status >/dev/null 2>&1 || gh auth login

[ -d .git ] || git init -b main
git add .
git diff --cached --quiet || git commit -m "feat: Liquid Notes — Liquid Glass notepad for Android"

if git remote get-url origin >/dev/null 2>&1; then
  echo "ℹ️  Remote 'origin' already exists, pushing…"
  git push -u origin main
else
  gh repo create "$REPO_NAME" "--$VISIBILITY" --source=. --remote=origin --push
fi

echo ""
echo "✅ Code is on GitHub. Triggering a Release build (APK)…"
gh workflow run release.yml -f tag=v1.0.0 || echo "ℹ️  Workflow will also run automatically on push (Android CI)."
sleep 5
gh run list --limit 3 || true
echo ""
echo "🎉 Done! Watch the build:   gh run watch"
echo "    Or open:  $(git remote get-url origin | sed 's/\.git$//')/actions"
echo "    The APK will appear under Releases + the workflow Artifacts."
